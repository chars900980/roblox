---
description: This Step will Compile your script and run it within a Vm
---

# Vmify

### Settings

None
